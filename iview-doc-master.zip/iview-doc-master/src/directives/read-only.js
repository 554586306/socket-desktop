export default {
    terminal: true,
    bind () {
        const el = this.el.innerHTML;
    },
    unbind () {

    }
}