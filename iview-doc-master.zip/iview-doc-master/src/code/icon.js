let code = {};

code.demo = `
<Icon type="checkmark" />
`;

code.render = `
<i class="ivu-icon ivu-icon-checkmark"></i>
`;

export default code;